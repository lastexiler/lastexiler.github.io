---
layout: page
title: About
permalink: /about/
---

This is Lastexiler. I'm documenting my learning notes in this blog. Send me an email: lastexiler.gh AT gmail.com if you have questions or find errors. Thanks :)
